#!/system/bin/sh
MODDIR=${0%/*}
FLAVOR=zygisk

log -p i -t "StorageIsolation" "post-fs-data ($FLAVOR)"

if [ "$ZYGISK_ENABLED" = false ] && [ "$FLAVOR" = "zygisk" ]; then
  log -p w -t "StorageIsolation" "Zygisk is disabled, skip zygisk-flavor script"
  exit 1
fi

if [ "$ZYGISK_ENABLED" = true ] && [ "$FLAVOR" = "riru" ]; then
  log -p w -t "StorageIsolation" "Zygisk is enabled, skip riru-flavor script"
  exit 1
fi

if [ "$FLAVOR" = "riru" ]; then
  magisk --path > "$MODDIR/magisk.path"
fi

if [ "$(getprop ro.product.cpu.abi)" != "arm64-v8a" ]; then
  log -p w -t "StorageIsolation" "Android 17 multi-user module supports arm64-v8a only"
  exit 0
fi

chmod 700 "$MODDIR"/starter
log -p w -t "StorageIsolation" "run $MODDIR/starter"
exec "$MODDIR/starter"
