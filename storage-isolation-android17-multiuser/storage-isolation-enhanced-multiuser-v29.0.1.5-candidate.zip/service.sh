#!/system/bin/sh
MODDIR=${0%/*}
SRC="$MODDIR/daemon-v355"
DST=/data/adb/storage-isolation/bin/daemon-v355
VERSION_FILE=/data/adb/storage-isolation/.server_version
EXPECTED_VERSION=355
# shortcut: Supports server version 355 only; update EXPECTED_VERSION after testing a new daemon.

[ "$(cat "$VERSION_FILE" 2>/dev/null)" = "$EXPECTED_VERSION" ] || {
  log -p w -t "StorageIsolation" "skip daemon patch: core service is not v$EXPECTED_VERSION"
  exit 0
}

TRIES=0
while [ ! -f "$DST" ] && [ "$TRIES" -lt 60 ]; do
  sleep 2
  TRIES=$((TRIES + 1))
done
[ -f "$DST" ] || {
  log -p w -t "StorageIsolation" "skip daemon patch: daemon was not created within 120 seconds"
  exit 0
}
cmp -s "$SRC" "$DST" && exit 0
cp -f "$SRC" "$DST" || exit 1
chmod 700 "$DST"
PID=$(pidof storage_isolation_daemon)
[ -n "$PID" ] || exit 0
kill -9 "$PID"
sleep 1
"$DST" >/data/local/tmp/storage-isolation-daemon.log 2>&1 &
